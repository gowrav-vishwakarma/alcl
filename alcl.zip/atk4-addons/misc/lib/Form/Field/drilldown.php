<?php
namespace misc;

// Left here for backward compatibilidty. Moved to hierarchy add-on.
class Form_Field_drilldown extends \hierarchy\Form_Field_drilldown {}
